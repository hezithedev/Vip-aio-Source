#pragma once
#include "framework.h"
#include "globals.h"
#include "sdk.h"
#include "ui.h"

extern ImFont* MainCaps;
extern ImFont* Main;
extern ImFont* FMenu;
extern ImFont* newnew;


class cMenu
{
public:
	void DrawMenu();
};